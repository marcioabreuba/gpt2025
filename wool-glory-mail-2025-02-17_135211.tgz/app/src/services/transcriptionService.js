// src/services/transcriptionService.js
import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Configuration, OpenAIApi } from 'openai';
import config from '../config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Faz o download do arquivo de áudio e salva localmente.
 */
async function downloadAudio(audioUrl) {
  const audioPath = path.join(__dirname, 'temp_audio.ogg');
  const response = await axios.get(audioUrl, { responseType: 'arraybuffer' });
  fs.writeFileSync(audioPath, response.data);
  return audioPath;
}

/**
 * Transcreve usando Whisper API.
 */
async function transcribeAudio(audioPath) {
  try {
    const configuration = new Configuration({ apiKey: config.openai.apiKey });
    const openai = new OpenAIApi(configuration);

    // "whisper-1" é o modelo de transcrição
    const resp = await openai.createTranscription(
      fs.createReadStream(audioPath),
      "whisper-1"
    );
    return resp.data.text;
  } catch (error) {
    console.error("Erro ao transcrever áudio:", error);
    throw error;
  }
}

/**
 * Combina download + transcrição e remove o arquivo no final.
 */
export async function handleAudioTranscription(audioUrl) {
  try {
    const audioPath = await downloadAudio(audioUrl);
    const text = await transcribeAudio(audioPath);
    fs.unlinkSync(audioPath); // remove arquivo temporário
    return text;
  } catch (error) {
    console.error("Erro no handleAudioTranscription:", error);
    throw error;
  }
}
