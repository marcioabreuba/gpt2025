// src/services/conversationService.js

import moment from 'moment-timezone';
import config from '../config.js';
import redisClient from '../redisClient.js';
import {
  createThread,
  getTimeBasedGreeting,
  storeMessageInConversation,
  addMessageWithRetry,
  getTokenUsage,
  summarizeContext,
  handleDeleteThread,
  waitForRunCompletion
} from './openaiService.js';
import { processImage } from './imageService.js';
import { sendReplyZAPI } from './zapiService.js';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: config.openai.apiKey });
const messageBuffers = new Map();
const bufferTimeouts = new Map();

/**
 * Lida com qualquer tipo de mensagem: texto, imagem, áudio, vídeo, PDF, etc.
 *
 * @param {string} userId - ID do usuário (chatLid)
 * @param {string} phone - Número do telefone para resposta
 * @param {string} message - Texto da mensagem (se houver)
 * @param {string} mediaUrl - URL do arquivo (imagem, áudio, vídeo, PDF, etc.)
 * @param {string} caption - Legenda adicional, se existir
 */
export async function getChat(userId, phone, message, mediaUrl, caption = '') {
  try {
    // Verifica se temos userId
    if (!userId) {
      throw new Error('userId é obrigatório');
    }

    // Se não tem texto nem mídia, erro
    if (!message && !mediaUrl) {
      throw new Error('É necessário ter texto ou algum arquivo para prosseguir.');
    }

    // Inicializa buffer
    if (!messageBuffers.has(userId)) {
      messageBuffers.set(userId, []);
    }

    // Decide se é texto ou mídia
    if (mediaUrl) {
      messageBuffers.get(userId).push({ type: 'media', mediaUrl, caption });
    } else {
      messageBuffers.get(userId).push({ type: 'text', message });
    }

    // Limpa timeout antigo se existir
    if (bufferTimeouts.has(userId)) {
      clearTimeout(bufferTimeouts.get(userId));
    }

    // Processa após 4s
    bufferTimeouts.set(userId, setTimeout(async () => {
      const bufferedMessages = messageBuffers.get(userId);
      messageBuffers.delete(userId);
      bufferTimeouts.delete(userId);

      const currentDate = moment().tz(config.timezone).format('DD/MM/YYYY');
      let threadId = await redisClient.get(`threadId:${userId}`);

      if (!threadId) {
        console.log(`Criando novo thread para o usuário ${userId}`);
        const greeting = getTimeBasedGreeting();
        const initialMessage = `${greeting} [Data: ${currentDate}]`;
        const thread = await createThread(userId, initialMessage);
        threadId = thread.id;
        await redisClient.set(`threadId:${userId}`, threadId);

        await storeMessageInConversation(userId, threadId, {
          role: 'user',
          content: initialMessage,
          timestamp: Date.now()
        });
      } else {
        const totalTokens = await getTokenUsage(threadId);
        if (totalTokens > 200000) {
          const summarizedContext = await summarizeContext(threadId);
          const thread = await createThread(
            userId,
            'Esta é uma continuação da conversa anterior. Contexto resumido:'
          );
          threadId = thread.id;
          await redisClient.set(`threadId:${userId}`, threadId);
          await addMessageWithRetry(threadId, summarizedContext);
        }
      }

      // Processa cada item no buffer
      for (const item of bufferedMessages) {
        if (item.type === 'text') {
          const formattedMessage = `${item.message} [Data: ${currentDate}]`;

          if (formattedMessage.toLowerCase().includes('apagar thread_id')) {
            await handleDeleteThread(userId);
            return;
          }

          await storeMessageInConversation(userId, threadId, {
            role: 'user',
            content: formattedMessage,
            timestamp: Date.now()
          });

          await addMessageWithRetry(threadId, formattedMessage);
        } else if (item.type === 'media') {
          // Tenta descobrir extensão
          let extension = '';
          try {
            const urlParts = item.mediaUrl.split('?')[0].split('.');
            extension = urlParts[urlParts.length - 1].toLowerCase();
          } catch (err) { /* ignore */ }

          // Se for imagem, chamamos processImage
          if (['jpg','jpeg','png','gif'].includes(extension)) {
            try {
              const description = await processImage(item.mediaUrl, item.caption);
              const instruction = `Descrição da imagem: ${description}`;
              await storeMessageInConversation(userId, threadId, {
                role: 'user',
                content: instruction,
                timestamp: Date.now()
              });
              await addMessageWithRetry(threadId, instruction);
            } catch (error) {
              console.error('Erro ao processar imagem:', error);
            }
          } else {
            // Se for áudio, vídeo, PDF, etc.
            const instruction = `O usuário enviou um arquivo do tipo ${extension || 'desconhecido'}. Legenda: ${item.caption}`;
            await storeMessageInConversation(userId, threadId, {
              role: 'user',
              content: instruction,
              timestamp: Date.now()
            });
            await addMessageWithRetry(threadId, instruction);
          }
        }
      }

      // Cria um run
      const run = await openai.beta.threads.runs.create(threadId, {
        assistant_id: config.openai.assistantId
      });

      await waitForRunCompletion(threadId, run.id);

      const messagesResponse = await openai.beta.threads.messages.list(threadId);
      const messages = messagesResponse.data.sort((a, b) => new Date(a.created_at || a.created) - new Date(b.created_at || b.created));
      const assistantMessages = messages.filter(m => m.role === 'assistant');
      const assistantMessage = assistantMessages[assistantMessages.length - 1];

      if (!assistantMessage) {
        throw new Error('Nenhuma mensagem do assistente encontrada.');
      }

      const assistantResponse = assistantMessage.content[0].text.value;
      await storeMessageInConversation(userId, threadId, {
        role: 'assistant',
        content: assistantResponse,
        timestamp: Date.now()
      });

      await sendReplyZAPI(phone, assistantResponse);

    }, 4000));
  } catch (error) {
    console.error("Erro no getChat:", error);
    throw error;
  }
}
