// src/routes/webhook.js
import express from 'express';
import logger from '../utils/logger.js';
import { getChat } from '../services/conversationService.js';
import { handleAudioTranscription } from '../services/transcriptionService.js';

const router = express.Router();

router.post("/webhook", async (req, res, next) => {
  try {
    logger.info("Webhook recebido", { payload: req.body });

    const {
      type,
      fromMe,
      phone,
      chatLid,
      text,
      image,
      audio,
      video,
      document
    } = req.body;

    if (type !== "ReceivedCallback" || fromMe || !phone) {
      return res.sendStatus(200);
    }

    let message = null;
    let mediaUrl = null;
    let caption = null;

    // Se for texto
    if (text && text.message) {
      message = text.message;
    }

    // Se for áudio
    if (audio && audio.audioUrl) {
      logger.info("Iniciando transcrição do áudio");
      const transcribedText = await handleAudioTranscription(audio.audioUrl);
      logger.info("Transcrição concluída", { transcribedText });

      // Em vez de passar mediaUrl, vamos converter para texto
      message = `Transcrição do áudio: ${transcribedText}`;
      // Se quiser, também pode manter mediaUrl, mas a IA não entenderá o áudio sem a transcrição
    }

    // Se for imagem
    if (image && image.imageUrl) {
      mediaUrl = image.imageUrl;
      caption = image.caption || ""; 
    }

    // Se for vídeo
    if (video && video.videoUrl) {
      mediaUrl = video.videoUrl;
      caption = video.caption || "";
    }

    // Se for documento (PDF, etc.)
    if (document && document.documentUrl) {
      mediaUrl = document.documentUrl;
      caption = document.fileName || "Documento PDF";
    }

    // Log
    logger.info("Mensagem recebida do usuário", { chatLid, phone, message, mediaUrl, caption });

    // Chama getChat
    await getChat(chatLid, phone, message, mediaUrl, caption);

    res.sendStatus(200);
  } catch (error) {
    logger.error("Erro no webhook", { error: error.message });
    next(error);
  }
});

export default router;
