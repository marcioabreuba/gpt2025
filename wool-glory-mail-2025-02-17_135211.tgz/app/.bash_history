npm install winston
npm uninstall node-fetch
npm install node-fetch@3
node -v
npm install openai@latest
npm install openai@latest axios
npm install openai@4.6.1
npm install openai@latest
npm ls openai
rm -rf node_modules package-lock.json
npm install
npm install express
rm -rf node_modules package-lock.json
rm -rf node_modules package-lock.json
rm -rf node_modules
rm -rf package-lock.json
npm install
npm ls openai
rm -rf node_modules package-lock.json
npm install
